#!/bin/bash
wc=`/root/agent/control status|grep started|wc -l`
if [ $wc -eq "0" ]
then
	/root/agent/control start
else
	echo "budengyu 10"
fi
#sed -i 's%#\* \* \* \* \* root /usr/bin/python /home/python/wxv5.py%* * * * * root /usr/bin/python /home/python/wxv5.py%g' testcro

